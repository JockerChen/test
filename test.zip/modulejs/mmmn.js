/*
 * @Author: [JokerChen]
 * @Date: 2020-09-26 20:08:51
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-09-29 18:56:54
 * @Description: 
 */

import { flag,subtraction,_Info } from "./aaa.js";

if(flag){
  console.log("我是个大天才");
}
// console.log(sum(10,10));
console.log(_Info);
console.log(subtraction(100,100));

