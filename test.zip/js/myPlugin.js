jQuery.fn.myPlugin=function(){
	//你自己的插件代码 
}

(function($){
	$.fn.myPlugin = function () {
    //你自己的插件代码
    };
})(jQuery);