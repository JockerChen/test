var oDevice=getBrowserType();
console.log(oDevice.intro);
$(function(){
	
})

//进行登录确认
