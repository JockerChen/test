/*
 * @Author: [JokerChen]
 * @Date: 2020-08-25 13:39:48
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-08-25 13:42:22
 * @Description: 请假管理
 */
function onlineSign() {
  console.log("请假管理onlineSign");
}
function localSign() {
  console.log("请假管理localSign");
}