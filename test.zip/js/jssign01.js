/*
 * @Author: [JokerChen]
 * @Date: 2020-08-25 13:39:48
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-08-25 13:41:36
 * @Description: 教师考勤
 */
function onlineSign() {
  console.log("教师考勤onlineSign");
}
function localSign() {
  console.log("教师考勤localSign");
}