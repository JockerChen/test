/*
 * @Author: [JokerChen]
 * @Date: 2020-08-25 13:39:48
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-08-25 13:42:05
 * @Description: 弹性离校
 */
function onlineSign() {
  console.log("弹性离校onlineSign");
}
function localSign() {
  console.log("弹性离校localSign");
}