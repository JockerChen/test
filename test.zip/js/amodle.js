/*
 * @Author: [JokerChen]
 * @Date: 2020-07-18 13:52:21
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-07-18 13:54:55
 * @Description: 
 */ 
import { ex1} from 'module.js';
console.log(typeof ex1);