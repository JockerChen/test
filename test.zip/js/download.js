function longContent1()
{
	setInterval(function(){
		console.log("是否继续执行1111111111111111111111");
	},1000)
}