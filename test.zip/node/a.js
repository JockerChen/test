/*
 * @Author: [JokerChen]
 * @Date: 2020-10-23 19:47:26
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-10-23 20:28:38
 * @Description: ""
 */
let info="chen";
exports.NoticeClass={
  ID:"12",
  NoticeTitle:"1231231231231",
  NoticeContent:"afdsadfsdfasfasdf"
}
//展示当前信息
exports.add=(a1,a2)=> a1+a2;
exports.info="chen1";;
