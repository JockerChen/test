/*
 * @Author: [JokerChen]
 * @Date: 2020-10-16 14:56:29
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-10-16 15:17:36
 * @Description: 
 */
var os =require("os");
console.log(os.cpus());
console.log(os.totalmem());
console.log(os.type());

