/*
 * @Author: [JokerChen]
 * @Date: 2020-10-23 19:50:17
 * @LastEditors: [JokerChen]
 * @LastEditTime: 2020-10-24 09:26:39
 * @Description: 
 */
var a=require("./a");
console.log(a.add(1,2));
console.log(a.NoticeClass);
console.log(a.info);
// let a1=1;
// let a2=3;
// console.log(a.add(a1,a2));  